package io.security.basicsecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BasicsecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
